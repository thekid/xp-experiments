#!/usr/bin/env python

from distutils.core import setup

setup(name = 'kvparser',
	version = '0.1.0',
	description = 'A simple hierarchical key-value text parser.',
	author = 'HAS',
	author_email = '',
	url='http://freespace.virgin.net/hamish.sanderson/index.html',
	license = 'LGPL',
	platforms = ['any'],
	py_modules = ['kvparser'],
	)