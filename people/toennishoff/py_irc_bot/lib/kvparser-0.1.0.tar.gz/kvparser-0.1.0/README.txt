To install kvparser, cd to the kvparser-0.1.0 directory and run:

	python setup.py install